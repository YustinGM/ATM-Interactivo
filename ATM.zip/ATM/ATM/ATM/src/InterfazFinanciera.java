import javax.swing.*;
import java.awt.*;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;

public class InterfazFinanciera extends JFrame {
    private CuentaBancaria cuenta;

    public InterfazFinanciera() {
        cuenta = new CuentaBancaria(5000000.00);  // 5 millones inicial

        setTitle("Gestor Financiero Personal");
        setSize(400, 300);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel(new GridLayout(0, 1, 10, 10));

        JButton verSaldo = new JButton("Ver saldo actual");
        JButton ingresar = new JButton("Realizar ingreso");
        JButton retirar = new JButton("Hacer retiro");
        JButton enviar = new JButton("Enviar fondos");
        JButton ahorrar = new JButton("Ahorrar dinero");
        JButton historial = new JButton("Ver historial");

        JButton salir = new JButton("Salir");

        // Configuración del formateador para números
        DecimalFormatSymbols symbols = new DecimalFormatSymbols();
        symbols.setGroupingSeparator('.');
        symbols.setDecimalSeparator(',');
        DecimalFormat df = new DecimalFormat("#,##0.00", symbols);

       
        
        verSaldo.addActionListener(e ->
            JOptionPane.showMessageDialog(this, "Tu saldo disponible es: " + formatoMillones(cuenta.obtenerSaldo()))
        );

        ingresar.addActionListener(e -> {
            String input = JOptionPane.showInputDialog("¿Cuánto deseas ingresar?");
            try {
                double monto = Double.parseDouble(input);
                cuenta.abonar(monto);
                JOptionPane.showMessageDialog(this, "Ingreso realizado. Nuevo saldo: $" + df.format(cuenta.obtenerSaldo()));
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Entrada inválida.");
            }
        });

        retirar.addActionListener(e -> {
            String input = JOptionPane.showInputDialog("¿Cuánto deseas retirar?");
            try {
                double monto = Double.parseDouble(input);
                if (cuenta.extraer(monto)) {
                    JOptionPane.showMessageDialog(this, "Retiro exitoso. Saldo restante: $" + df.format(cuenta.obtenerSaldo()));
                } else {
                    JOptionPane.showMessageDialog(this, "Fondos insuficientes.");
                }
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Entrada inválida.");
            }
        });

        enviar.addActionListener(e -> {
            String cuentaDestino = JOptionPane.showInputDialog("Cuenta destino:");
            String input = JOptionPane.showInputDialog("¿Cuánto deseas enviar?");
            try {
                double monto = Double.parseDouble(input);
                if (cuenta.extraer(monto)) {
                    JOptionPane.showMessageDialog(this, "Transferencia a " + cuentaDestino + " realizada.");
                } else {
                    JOptionPane.showMessageDialog(this, "Transferencia no realizada. Fondos insuficientes.");
                }
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Entrada inválida.");
            }
        });

        ahorrar.addActionListener(e -> {
            String input = JOptionPane.showInputDialog("¿Cuánto deseas ahorrar?");
            try {
                double monto = Double.parseDouble(input);
                if (cuenta.extraer(monto)) {
                    JOptionPane.showMessageDialog(this, "Dinero guardado exitosamente.");
                } else {
                    JOptionPane.showMessageDialog(this, "No se pudo realizar el ahorro.");
                }
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Entrada inválida.");
            }
        });

        historial.addActionListener(e -> {
            java.util.List<String> lista = cuenta.obtenerHistorial().obtenerHistorial();
            if (lista.isEmpty()) {
                JOptionPane.showMessageDialog(this, "No hay transacciones registradas.");
            } else {
                StringBuilder mensaje = new StringBuilder("Historial:\n");
                for (String t : lista) {
                    mensaje.append("- ").append(t).append("\n");
                }
                JOptionPane.showMessageDialog(this, mensaje.toString());
            }
        });

        salir.addActionListener(e -> System.exit(0));

        panel.add(verSaldo);
        panel.add(ingresar);
        panel.add(retirar);
        panel.add(enviar);
        panel.add(ahorrar);
        panel.add(historial);
        panel.add(salir);

        add(panel);
    }

    // Método para mostrar números grandes como texto amigable
    private String formatoMillones(double cantidad) {
        if (cantidad >= 1_000_000) {
            double millones = cantidad / 1_000_000;
            // Mostrar 1 decimal si no es entero
            if (millones == (long) millones) {
                return String.format("%d millones de pesos COP", (long) millones);
            } else {
                return String.format("%.1f millones de pesos COP", millones);
            }
        } else if (cantidad >= 1_000) {
            double miles = cantidad / 1_000;
            if (miles == (long) miles) {
                return String.format("%d mil pesos COP", (long) miles);
            } else {
                return String.format("%.1f mil pesos COP", miles);
            }
        } else {
            return String.format("%.0f pesos COP", cantidad);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new InterfazFinanciera().setVisible(true));
    }
}

public abstract class Transaccion {
    protected CuentaBancaria cuenta;

    public Transaccion(CuentaBancaria cuenta) {
        this.cuenta = cuenta;
    }

    public abstract void ejecutar();
}
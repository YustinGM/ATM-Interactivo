public class VerSaldo extends Transaccion {
    public VerSaldo(CuentaBancaria cuenta) {
        super(cuenta);
    }

    @Override
    public void ejecutar() {
        System.out.println("Tu saldo disponible es: $" + cuenta.obtenerSaldo());
    }
}
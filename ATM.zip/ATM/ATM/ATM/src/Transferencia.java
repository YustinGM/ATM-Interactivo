import java.util.Scanner;

public class Transferencia extends Transaccion {
    public Transferencia(CuentaBancaria cuenta) {
        super(cuenta);
    }

    @Override
    public void ejecutar() {
        Scanner sc = new Scanner(System.in);
        System.out.print("Número de cuenta destino: ");
        int cuentaDestino = sc.nextInt();
        System.out.print("Monto a transferir: ");
        double monto = sc.nextDouble();
        if (cuenta.extraer(monto)) {
            System.out.println("Transferencia realizada a cuenta " + cuentaDestino + ". Saldo actual: $" + cuenta.obtenerSaldo());
        } else {
            System.out.println("No fue posible completar la transferencia.");
        }
    }
}
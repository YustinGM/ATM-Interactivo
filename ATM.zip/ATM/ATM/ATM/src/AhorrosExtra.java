public class AhorrosExtra extends Transaccion {
    public AhorrosExtra(CuentaBancaria cuenta) {
        super(cuenta);
    }

    @Override
    public void ejecutar() {
        Scanner sc = new Scanner(System.in);
        System.out.print("¿Cuánto deseas guardar en tus ahorros? ");
        double monto = sc.nextDouble();
        if (cuenta.extraer(monto)) {
            cuenta.obtenerHistorial().registrar("Ahorro guardado: $" + monto);
            System.out.println("Guardado exitosamente. Saldo restante: $" + cuenta.obtenerSaldo());
        } else {
            System.out.println("Operación no completada. Intenta con otro valor.");
        }
    }
}

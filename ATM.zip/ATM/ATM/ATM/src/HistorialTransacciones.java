import java.util.ArrayList;
import java.util.List;

public class HistorialTransacciones {
    private final List<String> transacciones;

    public HistorialTransacciones() {
        transacciones = new ArrayList<>();
    }

    public void registrar(String descripcion) {
        transacciones.add(descripcion);
    }

    public List<String> obtenerHistorial() {
        return new ArrayList<>(transacciones);
    }

    public void mostrarHistorial() {
        if (transacciones.isEmpty()) {
            System.out.println("No hay transacciones registradas.");
        } else {
            System.out.println("Historial de transacciones:");
            for (String t : transacciones) {
                System.out.println("- " + t);
            }
        }
    }
}
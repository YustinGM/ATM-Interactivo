public class Ingreso extends Transaccion {
    public Ingreso(CuentaBancaria cuenta) {
        super(cuenta);
    }

    @Override
    public void ejecutar() {
        Scanner sc = new Scanner(System.in);
        System.out.print("Ingresa la cantidad a abonar: ");
        double monto = sc.nextDouble();
        if (monto > 0) {
            cuenta.abonar(monto);
            System.out.println("Ingreso realizado. Nuevo saldo: $" + cuenta.obtenerSaldo());
        } else {
            System.out.println("Monto inválido. Intenta nuevamente.");
        }
    }
}

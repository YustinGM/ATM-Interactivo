public class Extraccion extends Transaccion {
    public Extraccion(CuentaBancaria cuenta) {
        super(cuenta);
    }

    @Override
    public void ejecutar() {
        Scanner sc = new Scanner(System.in);
        System.out.print("Ingresa el monto a retirar: ");
        double monto = sc.nextDouble();
        if (cuenta.extraer(monto)) {
            System.out.println("Extracción exitosa. Saldo restante: $" + cuenta.obtenerSaldo());
        } else {
            System.out.println("Fondos insuficientes o monto inválido.");
        }
    }
}

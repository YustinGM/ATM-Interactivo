public class CuentaBancaria {
    private double saldo;
    private HistorialTransacciones historial;

    public CuentaBancaria(double saldoInicial) {
        this.saldo = saldoInicial;
        this.historial = new HistorialTransacciones();
    }

    public double obtenerSaldo() {
        return saldo;
    }

    public void abonar(double monto) {
        saldo += monto;
        historial.registrar("Ingreso: $" + monto);
    }

    public boolean extraer(double monto) {
        if (monto > 0 && monto <= saldo) {
            saldo -= monto;
            historial.registrar("Extracción: $" + monto);
            return true;
        }
        return false;
    }

    public HistorialTransacciones obtenerHistorial() {
        return historial;
    }
}
